variables
-Variables defined in role ‘defaults’
-Variables defined as group_vars
-Variables defined as host_vars
-Variables defined in plays
-Variables defined in role ‘vars’
-Variables defined at runtime with –e switch
